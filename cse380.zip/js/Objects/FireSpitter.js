FireSpitter = function(Game, x, y){


    this.update = function(){

    }
}