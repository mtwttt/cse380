Objects = function(Game, x, y){
    this.Game = Game;
    this.x = x;
    this.y = y;
};

Objects.prototype.update = function(){

};

Objects.prototype.whenInteract = function(){

}