Signs = function(Game, x, y){

    Objects.call(this, Game, x, y);

};

Signs.prototype = Object.create(Objects.prototype);

