FireSpitter = function(Game, x, y){

    


}
